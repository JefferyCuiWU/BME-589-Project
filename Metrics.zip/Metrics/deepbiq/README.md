# train
Download LIVE In the Wild Image Quality Challenge Database and put in ChallengeDB_release folder.
```
./train.sh
```
# reference 
[reference](https://github.com/zhl2007/pytorch-image-quality-param-ctrl)
